# SGCitizenAccount
PoC for SG Citizen Account

 - Spring Boot Application using Java 17 and on Spring Tools Suite v 4.18.1
 - After cloning the code, run `./gradlew bootRun` from root folder
 
 - Sample Request on URL http://localhost:8080/sg/person/applications/v1
 
 {
    "personID":"0",
    "nino": "SG000000A",
    "firstName": "",
    "dateOfBirth": "",
    "lastName": "",
    "postcode": ""
}

 - Sample Response
 
 [
    {
        "appTypeDesc": "Best Start Grant",
        "appStages": [
            {
                "stageDesc": "Application Received",
                "stageOrder": 0,
                "complete": false
            },
            {
                "stageDesc": "Application Assigned",
                "stageOrder": 1,
                "complete": false
            },
            {
                "stageDesc": "Checking Submitted Documents",
                "stageOrder": 2,
                "complete": false
            },
            {
                "stageDesc": "Pending with Case Manager",
                "stageOrder": 3,
                "complete": false
            },
            {
                "stageDesc": "Decision Made",
                "stageOrder": 4,
                "complete": false
            }
        ]
    },
    {
        "appTypeDesc": "Adult Disability Payment",
        "appStages": [
            {
                "stageDesc": "Application Received",
                "stageOrder": 0,
                "complete": false
            },
            {
                "stageDesc": "Application Assigned",
                "stageOrder": 1,
                "complete": false
            },
            {
                "stageDesc": "Checking Submitted Documents",
                "stageOrder": 2,
                "complete": false
            },
            {
                "stageDesc": "Pending with Case Manager",
                "stageOrder": 3,
                "complete": false
            },
            {
                "stageDesc": "Decision Made",
                "stageOrder": 4,
                "complete": false
            }
        ]
    }
]

 - Following scenarios are hard coded currently
 - SG000000A - One BSG Application in Received Status
 - SG000001B - One SCP Application with Decision Made and one ADP Application in 'Checking Submitted Documents' stage
 - SG000002C - An FSP Application with 'Pending with Case Manager' Status
 - SG000003D - An CDP Application with 'Application Assigned' status
 
