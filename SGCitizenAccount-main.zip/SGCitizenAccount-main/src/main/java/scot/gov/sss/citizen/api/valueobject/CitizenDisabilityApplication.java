package scot.gov.sss.citizen.api.valueobject;

public class CitizenDisabilityApplication extends CitizenApplication {

	public CitizenDisabilityApplication(String appTypeDesc) {

		super(appTypeDesc);

		// Set stages for Disability application

		getAppStages().add(new CitizenApplicationStage(CitizenConstants.APP_STAGE_RECEIVED, 0, false));
		getAppStages().add(new CitizenApplicationStage(CitizenConstants.APP_STAGE_ASSIGNED, 1, false));
		getAppStages().add(new CitizenApplicationStage(CitizenConstants.APP_STAGE_VERIFICATIONS, 2, false));
		getAppStages().add(new CitizenApplicationStage(CitizenConstants.APP_STAGE_CASE_MANAGER, 3, false));
		getAppStages().add(new CitizenApplicationStage(CitizenConstants.APP_STAGE_DECISION, 4, false));
	}
}
