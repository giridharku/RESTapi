package scot.gov.sss.citizen.api.valueobject;

public class CitizenApplicationStage {

	private String stageDesc = null;
	private int stageOrder = 0;
	private boolean isComplete = false;
	
	public CitizenApplicationStage(String stageDesc, int stageOrder, boolean isComplete) {
		super();
		this.stageDesc = stageDesc;
		this.stageOrder = stageOrder;
		this.isComplete = isComplete;
	}
	
	public String getStageDesc() {
		return stageDesc;
	}
	public void setStageDesc(String stageDesc) {
		this.stageDesc = stageDesc;
	}
	public int getStageOrder() {
		return stageOrder;
	}
	public void setStageOrder(int stageOrder) {
		this.stageOrder = stageOrder;
	}
	public boolean isComplete() {
		return isComplete;
	}
	public void setComplete(boolean isComplete) {
		this.isComplete = isComplete;
	}
}
