package scot.gov.sss.citizen.api.valueobject;

public class CitizenConstants {

	public static final String BSG_APP_DESC = "Best Start Grant";
	public static final String BSF_APP_DESC = "Best Start Foods";
	public static final String FSP_APP_DESC = "Funeral Support Payment";
	public static final String SCP_APP_DESC = "Scottish Child Payment";
	public static final String YCG_APP_DESC = "Young Carers Grant";
	public static final String JSP_APP_DESC = "Job Support Payment";
	public static final String CDP_APP_DESC = "Child Disability Payment";
	public static final String ADP_APP_DESC = "Adult Disability Payment";
	public static final String CSP_APP_DESC = "Carer Support Payment";
	
	public static final String APP_STAGE_RECEIVED = "Application Received";
	public static final String APP_STAGE_ASSIGNED = "Application Assigned";
	public static final String APP_STAGE_VERIFICATIONS = "Checking Submitted Documents";
	public static final String APP_STAGE_CASE_MANAGER = "Pending with Case Manager";
	public static final String APP_STAGE_DECISION = "Decision Made";
}
