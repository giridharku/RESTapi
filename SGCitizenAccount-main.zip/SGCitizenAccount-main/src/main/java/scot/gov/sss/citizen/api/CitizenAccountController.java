package scot.gov.sss.citizen.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import scot.gov.sss.citizen.api.valueobject.CitizenApplication;
import scot.gov.sss.citizen.api.valueobject.CitizenConstants;
import scot.gov.sss.citizen.api.valueobject.CitizenLIBApplication;
import scot.gov.sss.citizen.api.valueobject.CitizenSearchCriteria;

@RestController
@SpringBootApplication
public class CitizenAccountController {

	public static void main(String[] args) {
		SpringApplication.run(CitizenAccountController.class, args);
	}

	@PostMapping("/sg/person/applications/v1")
	public List<CitizenApplication> applications(@RequestBody CitizenSearchCriteria citizenSearchCriteria) {

		String nino = citizenSearchCriteria.getNino().trim();

		System.out.println("****** NINO: " + nino);

		List<CitizenApplication> appList = new ArrayList<>();

		if (!nino.isEmpty()) {

			if (nino.equals("SG000000A")) {

				CitizenApplication libApp = new CitizenLIBApplication(CitizenConstants.BSG_APP_DESC);

				libApp.getAppStage(CitizenConstants.APP_STAGE_RECEIVED).setComplete(true);

				appList.add(libApp);

			} else if (nino.equals("SG000001B")) {

				CitizenApplication libApp = new CitizenLIBApplication(CitizenConstants.SCP_APP_DESC);

				libApp.getAppStage(CitizenConstants.APP_STAGE_RECEIVED).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_ASSIGNED).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_VERIFICATIONS).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_CASE_MANAGER).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_DECISION).setComplete(true);

				appList.add(libApp);

				CitizenApplication disApp = new CitizenLIBApplication(CitizenConstants.ADP_APP_DESC);

				disApp.getAppStage(CitizenConstants.APP_STAGE_RECEIVED).setComplete(true);
				disApp.getAppStage(CitizenConstants.APP_STAGE_ASSIGNED).setComplete(true);
				disApp.getAppStage(CitizenConstants.APP_STAGE_VERIFICATIONS).setComplete(true);

				appList.add(disApp);
			} else if (nino.equals("SG000002C")) {

				CitizenApplication libApp = new CitizenLIBApplication(CitizenConstants.FSP_APP_DESC);

				libApp.getAppStage(CitizenConstants.APP_STAGE_RECEIVED).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_ASSIGNED).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_VERIFICATIONS).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_CASE_MANAGER).setComplete(true);

				appList.add(libApp);

			} else if (nino.equals("SG000003D")) {

				CitizenApplication libApp = new CitizenLIBApplication(CitizenConstants.CDP_APP_DESC);

				libApp.getAppStage(CitizenConstants.APP_STAGE_RECEIVED).setComplete(true);
				libApp.getAppStage(CitizenConstants.APP_STAGE_ASSIGNED).setComplete(true);

				appList.add(libApp);

			}

		}

		return appList;
	}

}
