package scot.gov.sss.citizen.api.valueobject;

import java.util.ArrayList;
import java.util.List;

public abstract class CitizenApplication {

	private String appTypeDesc = null;
	private List<CitizenApplicationStage> appStages = new ArrayList<>();

	public CitizenApplication() {
		super();
	}

	public CitizenApplication(String appTypeDesc) {
		super();
		this.appTypeDesc = appTypeDesc;
	}

	public String getAppTypeDesc() {
		return appTypeDesc;
	}

	public void setAppTypeDesc(String appTypeDesc) {
		this.appTypeDesc = appTypeDesc;
	}

	public List<CitizenApplicationStage> getAppStages() {
		return appStages;
	}

	public CitizenApplicationStage getAppStage(String stageName) {
		return appStages.stream().filter(details -> details.getStageDesc().equals(stageName)).findFirst().get();
	}

	public void setAppStages(List<CitizenApplicationStage> appStages) {
		this.appStages = appStages;
	}
}
