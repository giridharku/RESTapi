package scot.gov.sss.citizen.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitizenAccountControllerTests {

	@Test
	void contextLoads() {
	}

}
